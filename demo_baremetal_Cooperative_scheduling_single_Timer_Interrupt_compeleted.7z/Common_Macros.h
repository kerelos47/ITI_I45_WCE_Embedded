/*
 * Common_Macros.h
 *
 *  Created on: ??�/??�/????
 *      Author: Moaaz
 */

#ifndef COMMON_MACROS_H_
#define COMMON_MACROS_H_
//#define assig_bit(reg,bit_no,value)    ((regster)reg).Bit_##bit_no=value;
/*#define assig_bit(reg,bit_no,value)    \{\ if(value==0)\
										  \reg=(reg)&(~(((uint8)1)<< bit_no))\
										  \if(value==1)\
											reg=(reg)|(((uint8)1)<< bit_no)\}
*/

//#define assig_bit(reg,bit_no,value)		  reg=((reg)^(value<<bit_no))|(~(reg)^(value<<bit_no))
//#define assig_bit(reg,bit_no,value)      ((value==1)? (reg=(reg)|(((uint8)1)<< bit_no)):(reg)&(~(((uint8)1)<< bit_no))
#define assig_bit(reg,bit_no,value)		  reg=((((reg>>bit_no)&(uint8)0xfe)|(uint8)value)<<bit_no)|((reg<<(8-bit_no))>>(8-bit_no))
#define set_high_nibble(reg)			  reg=(reg)|(((uint8)0x0f)<< 4)
#define clear_high_nibble(reg)            reg=(reg)&((uint8)0x0f)
#define toggle_high_nibble(reg)           reg=(reg)^(((uint8)0x0f)<< 4)
#define get_high_nibble(reg)			  (reg >>4)
//#define assig_high_nibble(reg,value)	  reg=(reg & 0x value##0 )|(reg & 0x0f)
#define assig_high_nibble(reg,value)	  reg=(((reg<<4)>>4)|(value<<4))
//======================================================================
#define set_low_nibble(reg)               reg=(reg)|((uint8)0x0f)
#define clear_low_nibble(reg)             reg=(reg)&((uint8)0xf0)
#define toggle_low_nibble(reg)            reg=(reg)^((uint8)0x0f)
#define get_low_nibble(reg)			   	  (reg & 0x0f)
//#define assig_low_nibble(reg,value)	  reg=(reg & 0x 0##value )|(reg & 0xf0)
#define assig_low_nibble(reg,value)		  reg=(((reg>>4)<<4)|value)
//=======================================================================
#define rotate_cir_left(reg,no_rot)       reg=((uint8)(reg<<no_rot))|((uint8)(reg>>(8-no_rot)))
#define rotate_cir_right(reg,no_rot)      reg=((uint8)(reg>>no_rot))|((uint8)(reg<<(8-no_rot)))
#define get_bit(reg,bit_no)			  	  (((reg)&((0x01)<< bit_no))>> bit_no)
#define set_bit(reg,bit_no)               reg=(reg)|(((uint8)1)<< bit_no)
#define clear_bit(reg,bit_no)             reg=(reg)&(~(((uint8)1)<< bit_no))
#define toggle_bit(reg,bit_no)            reg=(reg)^(((uint8)1)<< bit_no)
//========================================================================


#endif /* COMMON_MACROS_H_ */
