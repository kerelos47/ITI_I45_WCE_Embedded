/*
 * Platform_datatypes.h
 *
 *  Created on: ??�/??�/????
 *      Author: Moaaz
 */

#ifndef PLATFORM_DATATYPES_H_
#define PLATFORM_DATATYPES_H_

typedef unsigned char   uint8 ;
typedef unsigned int	uint16;
typedef unsigned long   uint32;
typedef union {
				uint8 reg_data;
				struct{
						uint8 Bit_0 :1;
						uint8 Bit_1 :1;
						uint8 Bit_2 :1;
						uint8 Bit_3 :1;
						uint8 Bit_4 :1;
						uint8 Bit_5 :1;
						uint8 Bit_6 :1;
						uint8 Bit_7 :1;

										};
				}regster;
typedef struct {

	uint8 perodicity;
	uint8 offset;
	void(*task_ptr)(void);

}Task_StrConfg;

#endif /* PLATFORM_DATATYPES_H_ */
