/*

 * schedular.c
 *
 *  Created on: ??�/??�/????
 *      Author: Moaaz
 */

#include"Platform_datatypes.h"
#include"DIO.h"
#include"Common_Macros.h"
#include"Timer0_CTCInterrupt.h"

#define TASK1_OFFSET 1
#define TASK2_OFFSET 2
#define TASK3_OFFSET 3

#define TASK1_PERODICITY 1
#define TASK2_PERODICITY 2
#define TASK3_PERODICITY 3

typedef struct Task_StrConfg
{
	int offset;
	int perodicity;
	void(*task_ptr)();
	
}

void task_1()
{
	toggle_bit(PORTA,0);
}

void task_2()
{

	toggle_bit(PORTA,1);
}

void task_3()
{

   toggle_bit(PORTA,2);
}

Task_StrConfg TASK_QUEUE[3]={{TASK1_OFFSET,
                              TASK1_PERODICITY,
							  task_1},

							 {TASK2_OFFSET,
							  TASK2_PERODICITY,
							  task_2},

							 {TASK3_OFFSET,
							  TASK3_PERODICITY,
							  task_3}
							};
							
void Schdualer()
{	uint8 i=0;
	for(i=0;i<3;i++)
	{
		if(TASK_QUEUE[i].offset==0)
		{
			TASK_QUEUE[i].task_ptr();
			TASK_QUEUE[i].offset=TASK_QUEUE[i].perodicity-1;
		}
		else
		{
			TASK_QUEUE[i].offset--;
		}
	}
}
