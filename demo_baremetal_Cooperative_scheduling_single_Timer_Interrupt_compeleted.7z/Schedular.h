/*
 * Schedular.h
 *
 *  Created on: ??�/??�/????
 *      Author: Moaaz
 */

#ifndef SCHEDULAR_H_
#define SCHEDULAR_H_



#endif /* SCHEDULAR_H_ */
