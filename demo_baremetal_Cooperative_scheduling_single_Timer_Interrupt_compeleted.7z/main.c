/*

 * main.c
 *
 *  Created on: ??�/??�/????
 *      Author: Moaaz
 */


#include"DIO.h"
#include"Common_Macros.h"
#include"Platform_datatypes.h"

#define Timer0_CTC_INT   __vector_10
void    Timer0_CTC_INT (void) __attribute__((signal,__INTR_ATTRS));

uint16 global_interrupt_contor=0;
uint8 SEC_flag=0;

void Timer0_CTC_INT (void)
{  
   global_interrupt_contor++;
   if(global_interrupt_contor==5000)
   {
	   global_interrupt_contor=0;
	   SEC_flag=1;
   }
}

void main()
{	
	DDRA=0x07;
	set_bit(SREG,7);
	TIMSK=0;
	set_bit(TIMSK,1);
	TCCR0=0x09;
	OCR0=199;
	
	while(1)
	{
		if(SEC_flag==1)
		{
			Schdualer();
			SEC_flag=0;
		}
	}
}
